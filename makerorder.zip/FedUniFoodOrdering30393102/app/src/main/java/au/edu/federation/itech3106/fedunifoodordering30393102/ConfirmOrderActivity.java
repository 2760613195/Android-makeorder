package au.edu.federation.itech3106.fedunifoodordering30393102;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.math.BigDecimal;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

public class ConfirmOrderActivity extends AppCompatActivity {

    private String str;//传值食物种类
    private String strRg;//传值radiobutton
    private TextView food;
    private TextView food1;
    private TextView food2;
    private String foods;
    private String foodN;
    private double spend;
    private double spend1;
    private RadioGroup mRg1;
    private RadioButton mRb1;
    private RadioButton mRb2;
    private RadioButton mRb3;
    private Button btn1;
    private Button btn2;
    private static final String ID = "string";
    private int a;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirm_order);
        this.setTitle("Confirm Order");
        Intent intent=getIntent();
        Bundle bundle=intent.getExtras();
        str=bundle.getString("button");//str is three types of food
        foods=bundle.getString("food");//foods is all the costomise
        food=(TextView)findViewById(R.id.food);
        food1=(TextView)findViewById(R.id.food1);
        food1.setText(foods);
        foodN=bundle.getString("foodN");//foodN is choose number,first translate number then caculate the price
        food2=(TextView)findViewById(R.id.food3);
        food2.setText(foodN);

        spend=Integer.parseInt(foodN);

        btn1=findViewById(R.id.btn1);
        btn1.setOnClickListener(listener);
        btn2=findViewById(R.id.btn2);
        btn2.setOnClickListener(listener1);
        mRb1=(RadioButton)findViewById(R.id.rb1);
        mRb2=(RadioButton)findViewById(R.id.rb2);
        mRb3=(RadioButton)findViewById(R.id.rb3);
        //due to the different foodtype take the different text.
        if (str.equals("burger")){
            food.setText("Burger");
            mRb1.setText("Large Meal($4.99 extra)");
            mRb2.setText("Small Meal($2.49 extra)");
            mRb3.setText("No Meal");
        }else if(str.equals("pizza")){
            food.setText("Pizza");
            mRb1.setText("Large Meal($7.99 extra)");
            mRb2.setText("Small Meal($5.49 extra)");
            mRb3.setText("No Meal");
        }else {
            food.setText("Sundae");
            mRb1.setVisibility(View.GONE);
            mRb2.setVisibility(View.GONE);
            mRb3.setVisibility(View.GONE);
            spend=spend*0.15+2.49;
            String f=Double.toString(spend);
            //Take two decimal places
            BigDecimal b=new BigDecimal(f);
            spend1=b.setScale(2,BigDecimal.ROUND_HALF_UP).doubleValue();
            btn1.setText("PLACE ORDER($"+spend1+")");
        }

        mRg1 = (RadioGroup) findViewById(R.id.rg1);
        mRg1.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                RadioButton radioButton = (RadioButton) group.findViewById(checkedId);
                strRg=(String) radioButton.getText();

                //Calculate the total price through the selected Radiobutton
                if(strRg.equals("Large Meal($4.99 extra)")){
                    spend=spend*0.75+9.98;
                }else if(strRg.equals("Small Meal($2.49 extra)")){
                    spend=spend*0.75+7.48;
                }else if(strRg.equals("Large Meal($7.99 extra)")){
                    spend=spend*1.29+17.98;
                }else if(strRg.equals("Small Meal($5.49 extra)")){
                    spend=spend*1.29+15.48;
                }else if(strRg.equals("No Meal")){
                    if(str.equals("burger")){
                        spend=spend+4.99;
                    }else if(str.equals("pizza")) {
                        spend=spend+9.99;
                    }
                }
                String f=Double.toString(spend);
                //Take two decimal places
                BigDecimal b=new BigDecimal(f);
                spend1=b.setScale(2,BigDecimal.ROUND_HALF_UP).doubleValue();
                btn1.setText("PLACE ORDER($"+spend1+")");
                spend=Integer.parseInt(foodN);

            }
        });

    }



    private View.OnClickListener listener=new View.OnClickListener(){//点餐按钮
        @RequiresApi(api = Build.VERSION_CODES.O)
        public void onClick(View view){
            Intent intent = new Intent (ConfirmOrderActivity.this, MainActivity.class);
            PendingIntent pendingIntent=PendingIntent.getActivities(ConfirmOrderActivity.this,0,new Intent[]{intent},0);
            //Set the information popup window
            final NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            final NotificationCompat.Builder builder = new NotificationCompat.Builder(ConfirmOrderActivity.this, "subscribe")
                    .setContentTitle(str + " Ready!")
                    .setContentText(foods)
                    .setContentIntent(pendingIntent)
                    .setWhen(System.currentTimeMillis())
                    .setSmallIcon(R.mipmap.dollar)
                    .setLargeIcon(BitmapFactory.decodeResource(getResources(), R.mipmap.ic_launcher))
                    .setAutoCancel(true);
            //创建大文本样式(Create a large text style)
            NotificationCompat.BigTextStyle bigTextStyle = new NotificationCompat.BigTextStyle();
            bigTextStyle.setBigContentTitle(str + " Ready!")
                    .bigText(foods);
            builder.setStyle(bigTextStyle); //设置大文本样式

            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                NotificationChannel channel = new NotificationChannel("1", "Notify", NotificationManager.IMPORTANCE_DEFAULT);
                channel.enableLights(false); //是否在桌面icon右上角展示小红点
                channel.setLightColor(Color.GREEN); //小红点颜色
                channel.setShowBadge(true); //是否在久按桌面图标时显示此渠道的通知
                manager.createNotificationChannel(channel);
                builder.setChannelId("1");
            }

            TimerTask task = new TimerTask() {
                @Override
                public void run() {
                    Random random = new Random();
                    int m = random.nextInt(9999 - 1000) + 1000;
                    Notification notification = builder.build();
                    manager.notify(m, notification);
                }
            };

            //Set a time
            switch (str){
                case "burger":
                    Timer timer = new Timer();
                    timer.schedule(task, 10000);
                    break;
                case "pizza":
                    timer = new Timer();
                    timer.schedule(task, 20000);
                    break;
                case "ice" :
                    timer = new Timer();
                    timer.schedule(task, 5000);
                    break;
            }

            //文件的写入(write a file to store data)
            try {
                FileOutputStream fileOutputStream=openFileOutput("food.txt", Context.MODE_APPEND);
                OutputStreamWriter outputStreamWriter=new OutputStreamWriter(fileOutputStream,"UTF-8");
                outputStreamWriter.write(str+":\n"+foods+"&");
                outputStreamWriter.flush();
                fileOutputStream.flush();
                outputStreamWriter.close();
                fileOutputStream.close();
            }catch (FileNotFoundException e){
                e.printStackTrace();
            }catch (IOException e){
                e.printStackTrace();
            }
            startActivity(intent);
        }
    };
    private View.OnClickListener listener1=new View.OnClickListener(){//cancel button
        public void onClick(View view){
            Intent intent=new Intent(ConfirmOrderActivity.this,MainActivity.class);
            startActivity(intent);

        };
    };
}
