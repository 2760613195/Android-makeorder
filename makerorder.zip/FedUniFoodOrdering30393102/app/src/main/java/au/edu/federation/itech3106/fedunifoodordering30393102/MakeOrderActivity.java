package au.edu.federation.itech3106.fedunifoodordering30393102;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.res.ResourcesCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MakeOrderActivity extends AppCompatActivity {

    private CheckBox cb_1;
    private CheckBox cb_2;
    private CheckBox cb_3;
    private CheckBox cb_4;
    private CheckBox cb_5;
    private CheckBox cb_6;
    private CheckBox cb_7;
    private CheckBox cb_8;
    private Button btnNEXT;
    private String str;
    private String food;
    private int foodN;
    private String rstr;
    private TextView textView;
    private ImageView imageView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_make_order);
        Intent intent=getIntent();
        Bundle bundle=intent.getExtras();
        str=bundle.getString("button");
        //Accepts the value passed from MainActivity
        rstr=bundle.getString("rstr");
        //Accepts the value passed from OrderHistoryActivity
        textView=(TextView) findViewById(R.id.cost);
        imageView=(ImageView)findViewById(R.id.burger) ;
        btnNEXT = (Button) findViewById(R.id.btn);
        btnNEXT.setOnClickListener(listener);
        cb_1=findViewById(R.id.cb_1);
        cb_2=findViewById(R.id.cb_2);
        cb_3=findViewById(R.id.cb_3);
        cb_4=findViewById(R.id.cb_4);
        cb_5=findViewById(R.id.cb_5);
        cb_6=findViewById(R.id.cb_6);
        cb_7=findViewById(R.id.cb_7);
        cb_8=findViewById(R.id.cb_8);

        //when data from mainactivity,str have data,rstr is null;and when data from history activity,rstr hava data,str is null.
        if (rstr==null){
            if (str.equals("burger")) {
                this.setTitle("Ordering a Burger($4.99)");
                imageView.setImageResource(R.drawable.burger);
                textView.setText("$0.75 each");
                cb_1.setText("BBQ Sauce");
                cb_2.setText("Bacon");
                cb_3.setText("Beetroot");
                cb_4.setText("Cheese");
                cb_5.setText("Egg");
                cb_6.setText("Letture");
                cb_7.setText("Mayo");
                cb_8.setText("Onion");
            } else if (str.equals("pizza")) {
                this.setTitle("Ordering a Pizza($9.99)");
                imageView.setImageResource(R.drawable.pizza);
                textView.setText("$1.29 each");
                cb_1.setText("Anchovies");
                cb_2.setText("BBQ Sauce");
                cb_3.setText("Basil");
                cb_4.setText("Cheese");
                cb_5.setText("Chicken");
                cb_6.setText("Garlic");
                cb_7.setText("Ham");
                cb_8.setText("Mushroom");
            } else if (str.equals("ice")) {
                this.setTitle("Ordering a Sundae($2.99)");
                imageView.setImageResource(R.drawable.ice);
                textView.setText("$0.15 each");
                cb_1.setText("Banana");
                cb_2.setText("Caramel");
                cb_3.setText("Chocolate Topping");
                cb_4.setText("Chopped Nuts");
                cb_5.setText("Maple Syrup");
                cb_6.setText("Sherbet Synrup");
                cb_7.setText("Sherbet");
                cb_8.setVisibility(View.GONE);
                //不可见是VISIBLE
            }}else if (str==null) {
            //rstr is the food type and costomise.
            if (rstr.contains("burger")) {
                this.setTitle("Ordering a Burger($4.99)");
                imageView.setImageResource(R.drawable.burger);
                textView.setText("$0.75 each");
                cb_1.setText("BBQ Sauce");
                cb_2.setText("Bacon");
                cb_3.setText("Beetroot");
                cb_4.setText("Cheese");
                cb_5.setText("Egg");
                cb_6.setText("Letture");
                cb_7.setText("Mayo");
                cb_8.setText("Onion");
                if (rstr.contains("BBQ Sauce")){cb_1.setChecked(true);}
                if (rstr.contains("Bacon")){cb_2.setChecked(true);}
                if (rstr.contains("Beetroot")){cb_3.setChecked(true);}
                if (rstr.contains("Cheese")){cb_4.setChecked(true);}
                if (rstr.contains("Egg")){cb_5.setChecked(true);}
                if (rstr.contains("Letture")){cb_6.setChecked(true);}
                if (rstr.contains("Mayo")){cb_7.setChecked(true);}
                if (rstr.contains("Onion")){cb_8.setChecked(true);}
            } else if (rstr.contains("pizza")) {
                this.setTitle("Ordering a Pizza($9.99)");
                imageView.setImageResource(R.drawable.pizza);
                textView.setText("$1.29 each");
                cb_1.setText("Anchovies");
                cb_2.setText("BBQ Sauce");
                cb_3.setText("Basil");
                cb_4.setText("Cheese");
                cb_5.setText("Chicken");
                cb_6.setText("Garlic");
                cb_7.setText("Ham");
                cb_8.setText("Mushroom");
                if (rstr.contains("Anchovies")){cb_1.setChecked(true);}
                if (rstr.contains("BBQ Sauce")){cb_2.setChecked(true);}
                if (rstr.contains("Basil")){cb_3.setChecked(true);}
                if (rstr.contains("Cheese")){cb_4.setChecked(true);}
                if (rstr.contains("Chicken")){cb_5.setChecked(true);}
                if (rstr.contains("Garlic")){cb_6.setChecked(true);}
                if (rstr.contains("Ham")){cb_7.setChecked(true);}
                if (rstr.contains("Mushroom")){cb_8.setChecked(true);}
            } else if (rstr.contains("ice")) {
                this.setTitle("Ordering a Sundae($2.99)");
                imageView.setImageResource(R.drawable.ice);
                textView.setText("$0.15 each");
                cb_1.setText("Banana");
                cb_2.setText("Caramel");
                cb_3.setText("Chocolate Topping");
                cb_4.setText("Chopped Nuts");
                cb_5.setText("Maple Syrup");
                cb_6.setText("Sherbet Synrup");
                cb_7.setText("Sherbet");
                cb_8.setVisibility(View.GONE);
                //UNVISIBLE
                if (rstr.contains("Banana")){cb_1.setChecked(true);}
                if (rstr.contains("Caramel")){cb_2.setChecked(true);}
                if (rstr.contains("Chocolate Topping")){cb_3.setChecked(true);}
                if (rstr.contains("Chopped Nuts")){cb_4.setChecked(true);}
                if (rstr.contains("Maple Syrup")){cb_5.setChecked(true);}
                if (rstr.contains("Sherbet Synrup")){cb_6.setChecked(true);}
                if (rstr.contains("Sherbet,")){cb_7.setChecked(true);}
            }
        }
    }
    private View.OnClickListener listener=new View.OnClickListener()
    {
        @Override
        public void onClick(View view) {
            Intent intent = null;
            intent = new Intent(MakeOrderActivity.this, ConfirmOrderActivity.class);
            //because data from mainactivity or historyavtivity so that need judge
            if (rstr==null){
            if(str.equals("burger")){
                intent.putExtra("button","burger");
            }else if(str.equals("pizza")){
                intent.putExtra("button","pizza");
            }else {
                intent.putExtra("button","ice");
            }}else if (str==null){
                if(rstr.contains("burger")){
                    intent.putExtra("button","burger");
                }else if(rstr.contains("pizza")){
                    intent.putExtra("button","pizza");
                }else {
                    intent.putExtra("button","ice");
                }
            }
            //initialise food and take the costomise text in food,and take choose checkbox number in foodN
            food=" ";
            if(cb_1.isChecked()){food=(String) cb_1.getText();foodN=foodN+1;}
            if(cb_2.isChecked()){food=cb_2.getText()+","+food;foodN=foodN+1;}
            if(cb_3.isChecked()){food=cb_3.getText()+","+food;foodN=foodN+1;}
            if(cb_4.isChecked()){food=cb_4.getText()+","+food;foodN=foodN+1;}
            if(cb_5.isChecked()){food=cb_5.getText()+","+food;foodN=foodN+1;}
            if(cb_6.isChecked()){food=cb_6.getText()+","+food;foodN=foodN+1;}
            if(cb_7.isChecked()){food=cb_7.getText()+","+food;foodN=foodN+1;}
            if(cb_8.isChecked()){food=cb_8.getText()+","+food;foodN=foodN+1;}
            intent.putExtra("food",food);
            intent.putExtra("foodN",foodN+"");
            food=" ";
            foodN=0;
            startActivity(intent);
        }
    };
    //The top three points function
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu,menu);
        return true;
    }

    //allchecked and allnotchecked
    public boolean onOptionsItemSelected(MenuItem item){
        switch (item.getItemId()){
            case R.id.menuSelect:
                cb_1.setChecked(true);
                cb_2.setChecked(true);
                cb_3.setChecked(true);
                cb_4.setChecked(true);
                cb_5.setChecked(true);
                cb_6.setChecked(true);
                cb_7.setChecked(true);
                cb_8.setChecked(true);
                break;
            case R.id.menuClear:
                cb_1.setChecked(false);
                cb_2.setChecked(false);
                cb_3.setChecked(false);
                cb_4.setChecked(false);
                cb_5.setChecked(false);
                cb_6.setChecked(false);
                cb_7.setChecked(false);
                cb_8.setChecked(false);
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}
