package au.edu.federation.itech3106.fedunifoodordering30393102;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class OrderHistoryActivity extends AppCompatActivity {

    private String[] strings = new String[]{};
    private Button mBtn;
    private String itemString;
    private TextView tvHis;
    ArrayAdapter<String> adapter;
    ListView mylistview;
    List<String> lis;
    String food = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_history);
        this.setTitle("Order History");
        tvHis=findViewById(R.id.tvHis);
        mBtn=(Button) findViewById(R.id.btnR);
        mBtn.setEnabled(false);
        mBtn.setBackgroundColor(Color.parseColor("#919191"));
        //内部文件的读
        try {
            FileInputStream fileInputStream = openFileInput("food.txt");
            InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream, "UTF-8");
            char content[] = new char[fileInputStream.available()];
            inputStreamReader.read(content);
            inputStreamReader.close();
            fileInputStream.close();
            food = new String(content);
            strings = food.split("&");
            lis = Arrays.asList(food.split("&"));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        if (food==null||"".equals(food)) {
            tvHis.setText("you have no history order");

        }else{
            System.out.println(strings.length+"1");
            mylistview = (ListView) findViewById(R.id.list_view);
            adapter = new ArrayAdapter<String>(this, R.layout.layout_linear_item, strings);
            mylistview.setAdapter(adapter);
            //adapter onclick event
            mylistview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                    itemString = ((TextView) view).getText().toString();
                    Toast.makeText(OrderHistoryActivity.this, "you choose item：" + itemString, Toast.LENGTH_LONG).show();
                    mBtn.setBackgroundColor(Color.parseColor("#008577"));
                    if (itemString != null) {
                        mBtn.setEnabled(true);
                    }
                }
            });
        }
    }
    //when choose item ,get itemString to store data,above food type and customise when you history choosed.
        public void onClickR(View view) {
            Intent intent = null;
            intent = new Intent(OrderHistoryActivity.this, MakeOrderActivity.class);
            intent.putExtra("rstr",itemString);
            startActivity(intent);
        }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menuh,menu);
        return true;
    }
    //because the reverse easy to take but i can't maintain it,so when clicked menu,i want read data to file again.
    public boolean onOptionsItemSelected(MenuItem item){
        switch (item.getItemId()){
            case R.id.menuNew:
                if (food==null||"".equals(food)) {
                    tvHis.setText("you have no history order");
                }else {
                    //read food.txt file
                    try {
                        FileInputStream fileInputStream = openFileInput("food.txt");
                        InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream, "UTF-8");
                        char content[] = new char[fileInputStream.available()];
                        inputStreamReader.read(content);
                        inputStreamReader.close();
                        fileInputStream.close();
                        String food = new String(content);
                        strings = food.split("&");
                        lis = Arrays.asList(food.split("&"));
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    adapter=new ArrayAdapter<String>(this,R.layout.layout_linear_item,lis);
                    Collections.reverse(lis);
                    mylistview.setAdapter(adapter);
                }
            break;
            case R.id.menuOld:
                if (food==null||"".equals(food)) {
                    tvHis.setText("you have no history order");
                }else {
                    //read food.txt file
                    try {
                        FileInputStream fileInputStream = openFileInput("food.txt");
                        InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream, "UTF-8");
                        char content[] = new char[fileInputStream.available()];
                        inputStreamReader.read(content);
                        inputStreamReader.close();
                        fileInputStream.close();
                        String food = new String(content);
                        strings = food.split("&");
                        lis = Arrays.asList(food.split("&"));
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    adapter=new ArrayAdapter<String>(this,R.layout.layout_linear_item,lis);
                    mylistview.setAdapter(adapter);
                }
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}

