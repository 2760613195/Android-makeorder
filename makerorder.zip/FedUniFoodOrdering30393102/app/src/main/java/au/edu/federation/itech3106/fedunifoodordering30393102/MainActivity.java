package au.edu.federation.itech3106.fedunifoodordering30393102;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class MainActivity extends AppCompatActivity {
//initial buttons
    private Button mBtnBURGER;
    private Button mBtnPIZZA;
    private Button mBtnICECREAM;
    private Button mBtnHISTORY;
    public int a=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.setTitle("Foodle!");
        mBtnBURGER=(Button)findViewById(R.id.buttonB);
        mBtnPIZZA=(Button) findViewById(R.id.buttonP);
        mBtnICECREAM=(Button) findViewById(R.id.buttonI);
        mBtnHISTORY=(Button)findViewById(R.id.buttonH);
        mBtnBURGER.setOnClickListener(listenerB);
        mBtnPIZZA.setOnClickListener(listenerP);
        mBtnICECREAM.setOnClickListener(listenerI);
        mBtnHISTORY.setOnClickListener(listenerH);

    }
    private View.OnClickListener listenerB=new View.OnClickListener()
    {
        @Override
        public void onClick(View view) {
            Intent intent = null;
            intent = new Intent(MainActivity.this, MakeOrderActivity.class);
            intent.putExtra("button","burger");//use intent translate data
            startActivity(intent);
        }
    };
    private View.OnClickListener listenerP=new View.OnClickListener()
    {
        @Override
        public void onClick(View view) {
            Intent intent = null;
            intent = new Intent(MainActivity.this, MakeOrderActivity.class);
            intent.putExtra("button","pizza");
            startActivity(intent);
        }
    };
    private View.OnClickListener listenerI=new View.OnClickListener()
    {
        @Override
        public void onClick(View view) {
            Intent intent = null;
            intent = new Intent(MainActivity.this, MakeOrderActivity.class);
            intent.putExtra("button","ice");
            startActivity(intent);
        }
    };
    private View.OnClickListener listenerH=new View.OnClickListener()
    {
        @Override
        public void onClick(View view) {
            Intent intent = null;
            intent = new Intent(MainActivity.this, OrderHistoryActivity.class);
            startActivity(intent);
        }
    };
//history data stored in data.txt file,when app turn off delete file.
    @Override
    protected void onDestroy() {
        super.onDestroy();
        DataCleanManager.DeleteFile((new File("data/data/"+getPackageName())));
    }
}
