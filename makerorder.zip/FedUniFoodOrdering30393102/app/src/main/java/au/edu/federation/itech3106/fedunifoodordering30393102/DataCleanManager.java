package au.edu.federation.itech3106.fedunifoodordering30393102;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.File;
//A custom class used to delete files

public class DataCleanManager {
    public static void DeleteFile(File file) {
        if (file.exists() == false) {
            return;
        } else {
            if (file.isFile()) {
                file.delete();
                return;
            }
            if (file.isDirectory()) {
                File[] childFile = file.listFiles();
                if (childFile == null || childFile.length == 0) {
                    file.delete();
                    return;
                }
                for (File f : childFile) {
                    DeleteFile(f);
                }
                file.delete();
            }
        }
    }
}